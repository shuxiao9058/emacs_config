
Road-bash                 http://www.qhull.org/road/bash/doc/road-bash.html

   A portable bash shell for Linux, Windows, MacOS, Cygwin, MINGW, and Unix
   Version 2010.1   2010/01/12

Copyright 2005-2010, C.B. Barber
Documentation and copyright notices are in /doc
Copyrights are GPL or open source.

---------------------------
-- Installation
---------------------------

On Unix, Cygwin, Linux, MacOS, etc.
-- Extract the tgz file to your home directory (~/)
-- Copy ~/bash/etc/skel/.* to ~/
-- [Optional] Copy ~/bash/etc/road* to /etc
-- Source ~/.bashrc
-- Execute bash/local/bin/road-test.sh

On Windows
-- Extract the zip file to C: (or another location)
-- Double-click the road bash icon (a green tree)
-- Execute road-test.sh
-- Execute util/bash.bat to switch from cmd to bash

On MinGW
-- Follow the installation instructions for Windows
-- Rename /bash/etc/fstab.sample to fstab
-- Edit fstab and update the location of your /mingw directory
-- Use bash/util/msys.bat (rxvt) or bash/bash.lnk (windows)

---------------------------
-- Contents
---------------------------

The tgz distribution includes bash/etc, bash/doc/*, and bash/local road scripts

bash/bin
-- Executable files from MSYS, a minimal system for MINGW
   http://www.mingw.org/msys.shtml
   Additional downloads may be found at
   http://sourceforge.net/projects/mingw/files/
-- Documentation and copyright notices are in bash/doc/msys
   Copyrights are GPL or open source.
   Invoke with --help for usage notes
-- Contents of the bin directory for MSYS-1.0.11
   http://downloads.sourceforge.net/mingw/MSYS-1.0.11.exe
-- sed.exe replaced by a later release.  See bash/local/README.txt
-- sort.exe replaced by a later version.  See bash/local/README.txt

bash/doc
-- Documentation and copyright notices
-- COPYING.txt -- Copyright notice for Road-bash
-- Changes.txt -- Change history for Road-bash
-- road-bash.html -- Documentation for Road-bash

bash/etc
-- Configuration directory
-- fstab.sample and termcap from MSYS
-- profile initializes $PATH, $HOME, etc.
-- road-bashenv.sh initializes the bash environment
-- road-bashrc.sh initializes an interactive environment
-- road-hostrc.sh.sample for shared aliases and namedirs
-- road-script.sh defines a scripting environment

bash/etc/skel
-- Initialization files for user home directories
-- road-root.bash_profile for distinguishing users by SSH key [wsears]
-- .bashrc invokes etc/road-bashenv.sh, etc/road-bashrc.sh, ~/.bashenv
-- .inputrc is the initialization file for bash's readline()
-- .profile invokes .bashrc for login shells
-- .vimrc is the initialization file for vim

bash/home
-- User home directories created by /etc/profile

bash/local
-- Unix-like packages and programs
-- Place each package in a sub-directory with proxies in bash/local/bin
-- See bash/local/README.txt

Road scripts in bash/local/bin
-- p4edit opens-for-edit modified files (Perforce)
-- road-make.sh creates the bash and road distributions
-- road-test.sh tests the bash installation

bash/util
-- Windows utilities and bat files (e.g., sysinternals)
-- bash.bat invokes bash.  Use 'b' to return to current directory
-- See bash/util/README.txt

bash/var
-- Miscellaneous files and directories
-- /var/log for log files
-- /var/tmp for temporary files

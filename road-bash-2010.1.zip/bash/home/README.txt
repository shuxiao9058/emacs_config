
Contents of /home            http://www.qhull.org/bash/doc/road-bash.html

    Home directories for users ($HOME, ~/) 

    Automatically created by /etc/profile from /etc/skel

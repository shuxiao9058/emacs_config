/util -- Windows utilites and bat files

Notes
    Useful, small, inexpensive and free utilities go here.
    See doc/road-bash.html#road-bash-util for suggestions
    Add C:\bash\util to System->Advanced->Environment Variables->PATH

Links to /bin programs
    bash.bat -- Invoke bash (bin/sh).  Use 'b' to return to directory.
    MSYS.bat -- Invoke rxvt or bash

Links to /util programs
    wzzip, wzunzip -- install /util/WinZip with command line
    $EDITOR -- install /util/TextPad


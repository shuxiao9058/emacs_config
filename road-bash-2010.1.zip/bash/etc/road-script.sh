#/etc/bash-script.sh -- set up scripting environment
#
#  http://www.qhull.org/bash/doc/road-bash.html
#
#  Sourced by scripts
#  It sources /etc/road-bashenv.sh.  road-bashenv.sh sources /etc/road-hostenv.sh
#
# $Id: //main/2005/road/road-bash/etc/road-script.sh#18 $
# $Change: 1090 $$DateTime: 2009/11/23 22:12:07 $$Author: bbarber $

# ====== define names =========================

RO_RUN_DIR=$PWD
if [[ "$RO_RUN_DIR" = "/" ]]; then
    RO_RUN_DIR=/.
fi

if [[ ! $(type -p ls) ]]; then
    PATH="/usr/local/bin:/bin:$PATH"
fi
if [[ -r $HOME/bash/etc/road-bashenv.sh ]]; then
    source $HOME/bash/etc/road-bashenv.sh
elif [[ -r /etc/road-bashenv.sh ]]; then
    source /etc/road-bashenv.sh
elif [[ ! $(type -a ro_minute 2>/dev/null) ]]; then
    echo -e "road-script.sh -- road-bashenv.sh was not sourced. It is not in /etc or ~/bash/etc\n... Either move the file or source it before road-script."
    exit 1
fi

set -o pipefail 2>/dev/null # Bash 3 propagates errors across pipes

# Mac OS X does not support -r, nor MSYS -E
if sed -E </dev/null 2>/dev/null; then
    alias sed_r='sed -E'
else
    alias sed_r='sed -r'
fi

#Literals for end-of-line and path separators.  Programs also produce \n.  Probably best to use \n everywhere
if [[ $IS_WINDOWS ]]; then
   EOL=\\r\\n
   SEP=\\
else
   EOL=\\n
   SEP=/
fi

if [[ $IS_BASH3 ]]; then
    function ro_here # Bash 3 call depth and function name for logging
    {
       echo $SHLVL-${FUNCNAME[1]}
    } 
fi

##############################
# Configure error handling
#
#  Do nothing before testing $?.  $? is reset by echo, err_log=, etc.  Function call OK

err_program=${err_program:-road-script}
err_log="${err_log:-$TMP/$err_program-$(ro_today)-$$.log}" 
err_step_log="${err_step_log:-$TMP/$err_program-$(ro_today)-$$-step.log}"
is_running="${is_running:-$RO_RUN_DIR/IS_RUNNING.txt}"

function check_err_log # $LINENO file -- create log_file with absolute path, exit on failure
{

    if [[ "${2:0:1}" != "/" ]]; then
        exit_err $1 "Pathname for log file does not start with root, '/...'$EOL... Allows logging from any directory$EOL...\$err_log/err_step_log=$1"
    fi
    check_err_log_rel "$@"
}

function check_err_log_rel # $LINENO file -- create log_file, maybe relative, exit on failure
{
    local -r log_file="$2"
    local -r log_dir="${log_file%/*}"

    if [[ $# -ne 2 ]]; then
        echo -e "bash.env:check_err_log_quick requires 2 argument: LINENO=$1 log_file=$2"
        exit 1  # do not use exit_isrunning -- need to debug first
    fi
    if [[ "$log_file" == "" || "${log_file% *}" != "$log_file" ]]; then
        exit_err $1 "Pathname for error log is empty or includes a space.$EOL... \$err_log/err_step_log=$log_file"
    fi
    if [[ "$log_dir" != "" && ! -d "$log_dir" ]]; then
        mkdir -p "$log_dir"
        exit_if_err $1 "Can not read or create error log directory.$EOL... \$log_dir=$log_dir$EOL... \$err_log/err_step_log=$log_file"
    fi
    if [[ ! -e "$log_file" ]]; then
        echo -n > "$log_file"
        exit_if_err $1 "Need write access to $log_file"
        rm "$log_file"
    elif [[ ! -w $log_file ]]; then
        exit_err $1 "Can not write to $log_file"
    else
        echo >> $log_file   # 'touch' does not trip in-use error
        exit_if_err $1 "$log_file is in use by another process"
        rm "$log_file"
    fi
}

function check_isrunning # exit if $is_running already exists
{
    HERE=check_isrunning
    log_note $HERE "Check if another instance is running" 
    if [[ -e "$is_running" ]]; then
        log_step $HERE "Either $err_program reported an error or it is running.$EOL... To rerun, delete '$is_running'"
        rm $err_log  # the latest log file contains the run that failed
        exit 1;
    fi

    echo "$err_program -- $0 started " $(date) >"$is_running"
    if [[ $? -ne 0 ]]; then
        log_err $HERE "ERROR: Could not modify or create file, $is_running"
        exit 1;
    fi
 }

function exit_err # $LINENO message -- exit 
{
    log_err "$@"
    exit 1 # do not use exit_isrunning -- need to debug first
}

function exit_err_file # $LINENO message err_file -- exit 
{
    log_err_file "$@"
    exit 1  # do not use exit_isrunning -- need to debug first
}

# Warning: 'cp' apparently does not set exit status on copy failures
function exit_if_err # $LINENO message -- exit if non-zero error status
{
    # Need to test for error status first
    if [[ $? -ne 0 ]]; then
        exit_err "$@"
    fi
}

function exit_if_err_file # $LINENO message err_file -- exit if error status or err_file non-empty
{
    # Need to test for error status first
    if [[ $? -ne 0 || -s $3 ]]; then
        exit_err_file "$@"
    fi
    if [[ $# -ne 3 ]]; then
        exit_err $1 "bash.env exit_if_err_file requires 3 arguments:$EOL... LINENO=$1$EOL... Message=$2$EOL... File=$3"
    fi
}

function exit_if_fail # $LINENO 'cmd args' -- execute command, exit on failure
{
    log_note "$1" "Execute -- $2"
    eval "$2" >>$err_log 2>&1
    exit_if_err $LINENO "Command failed to execute -- $2"
}

function exit_isrunning # exit after deleting $is_running
{
    if [[ -e "$is_running" ]]; then
        rm "$is_running"
    fi
    exit 0 # success
}

function log_err # $LINENO message -- log message to event queue and err_log
{
    #if type -p eventcreate >/dev/null; then
    #    echo "eventcreate /l Application /so \"$err_program\" /t Error /id \"$(($1 < 0 ? - $1 : $1))\" /d \"$2\"" >>"$err_log"
    #    eventcreate //l Application //so "$err_program" //t Error //id "$(($1 < 0 ? - $1 : $1))" //d "$2" >/dev/null
    #fi
    log_step $1 "$2$EOL... See $err_log"
    echo =============== >>$err_log
    if [[ $# -ne 2 ]]; then
        echo -e "bash.env:log_err() requires 2 arguments: LINENO=$1 Message=$2EOL"
    fi
}

function log_err_file # $LINENO message file -- log message and file to err_log
{

    #if type -p eventcreate >/dev/null; then
    #    echo "eventcreate /l Application /so \"$err_program\" /t Error /id \"$1\" /d \"$2 $(head $3)\"" >>"$err_log"
    #eventcreate //l Application //so "$err_program" //t Error //id "$1" //d "$2 $(head $3)" >/dev/null
    #fi
    log_step $1 "$2$EOL... See $err_log"
    echo -e "===============$EOL" >>$err_log
    cat $3 >>$err_log
    if [[ $# -ne 3 ]]; then
        echo -e "bash.env:log_err_file requires 3 arguments: LINENO=$1 Message=$2 File=$3$EOL"
    fi
}

function log_if_err # $LINENO message -- log if non-zero error status
{
    # Need to test for error status first
    if [[ $? -ne 0 ]]; then
        log_err "$@"
    fi
}

function log_if_err_file # $LINENO message err_file -- log if error status or err_file non-empty
{
    # Need to test for error status first
    if [[ $? -ne 0 || -s $3 ]]; then
        log_err_file "$@"
    fi
    if [[ $# -ne 3 ]]; then
        exit_err $1 "bash.env log_if_err_file requires 3 arguments:$EOL... LINENO=$1$EOL... Message=$2$EOL... File=$3"
    fi
}

function log_note # $LINENO message -- log to error file
{
    echo -e -n "$EOL" >>$err_log
    echo -e -n "$err_program" "$1" $(ro_now) === "$2$EOL" >>$err_log
}

function log_step # $LINENO message -- log to error file and console
{
    echo -e "$1" $(ro_minute) "$2"
    echo -e -n "$err_program" "$1" $(ro_now) === "$2$EOL" >>$err_step_log
    log_note "$1" "$2"
}

# </pre>

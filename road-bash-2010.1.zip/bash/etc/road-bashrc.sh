#/etc/road-bashrc.sh -- system wide bash file for both NT and Unix
#
# http://www.qhull.org/bash/doc/road-bash.html
#
# Sourced by ~/.bashrc after it sources /etc/road-bashenv.sh
# When done, it sources /etc/road-hostrc.sh and ~/.bash-$HOST
#
# $Id: //main/2005/road/road-bash/etc/road-bashrc.sh#19 $
# $Change: 1133 $$DateTime: 2010/01/02 15:13:05 $$Author: bbarber $

# ====== define names =========================

# Include user's ~/bin directory in PATH -- not exported.  Do not use ~ since it is not always expanded.
if [[ -d $HOME/bin && ${PATH/*$HOME\/bin*} ]]; then
   PATH="$HOME/bin:$PATH"
fi

# set the prompt to host and cwd
PS1="\h-\w> "

# set options -- if shopt not available, bash is too old
shopt -s cdable_vars cmdhist histappend checkwinsize

CDPATH=.:..:../..:../../..:$HOME
export CDPATH

if [[ $IS_WINDOWS ]]; then
    alias dir='explorer . &'
fi

function namedir #
{   #   requires shopt -s cdable_vars
    if [[ $# -ne 2 ]]; then # Redefining 'local' changes its builtin meaning
        echo -e "Usage: namedir name dir -- Define name as directory [road-bashrc.sh, ~/.bash-*]\n.. 'namedir $1 $2'"
        return 1
    fi
    if [[ $1 == "local" ]]; then # Redefining 'local' changes its builtin meaning
        echo "namedir [road-bashrc.sh]: invalid name -- 'namedir $1 $2'"
        return 1
    fi
    export $1="$2"
    alias $1="cd \"$2\""
}
function mydir #name -- assign $name and alias to the current directory
{   
    namedir $1 "$PWD"
    mv -f "$HOME/.bash-$HOST" "$HOME/.bash-$HOST-bak"
    grep -v "namedir $1[ \t]" "$HOME/.bash-$HOST-bak" >"$HOME/.bash-$HOST"
    echo namedir $1 \"$PWD\" >>"$HOME/.bash-$HOST"
}
function myname #name dir -- assign $name and alias to $dir
{   namedir $1 "$2" 
    mv -f "$HOME/.bash-$HOST" "$HOME/.bash-$HOST-bak"
    grep -v "namedir $1[ \t]" "$HOME/.bash-$HOST-bak" >"$HOME/.bash-$HOST"
    echo namedir $1 \"$2\" >>"$HOME/.bash-$HOST"
}
function rmmy #name -- remove $name from .bash-$HOST
{   mv -f "$HOME/.bash-$HOST" "$HOME/.bash-$HOST-bak"
    grep -v ${1:-xyzsdfasdf} "$HOME/.bash-$HOST-bak" >"$HOME/.bash-$HOST"
    unalias $1
    unset $1
}
function findmy #name -- list matching namedirs
{   if [[ -r /etc/road-hostrc.sh ]]; then
        cat /etc/road-hostrc.sh "$HOME/.bash-$HOST" | grep namedir | sort | cut -c8- | grep -i ${1:-.}
    else
        cat "$HOME/.bash-$HOST" | grep namedir | sort | cut -c8- | grep -i ${1:-.}
    fi
}

alias b='cd "$OLDPWD"'
alias c='cd' 
alias c1='cd ..'
alias c2='cd ../..'
alias c3='cd ../../..'
alias c4='cd ../../../..'
alias c5='cd ../../../../..'
alias c6='cd ../../../../../..'
function cc #dirname -- list and goto directory
{       cd $1; ls -C -F | head -15 
}
alias copy=cp
alias del=rm
function dos2u
{
    if [[ $# -ne 1 ]]; then
        echo 'Usage: dos2u file -- strip \r'
    elif [[ ! $TMP ]]; then
        echo '$TMP is not defined'
    else
        cat $1 | tr -d '\r' >$TMP/dos2u.$$
        if [[ -s $TMP/dos2u.$$ ]]; then
            mv $TMP/dos2u.$$ $1
        fi
    fi
}
function e #files -- edit files using $EDITOR
{
    if [[ $IS_WINDOWS ]]; then
        "$EDITOR" "$@" &
    else
        "$EDITOR" "$@" 
    fi
}
function finda #alias -- find matching aliases and functions
{
    (for f in /etc/road-*.sh $HOME/.bashenv $HOME/bash/etc/road-*.sh; do 
       if [[ -f $f ]]; then cat $f ; fi 
     done) | sed -n -e 's/^[^a-zA-Z]*alias //p' -e 's/^[^a-zA-Z]*function \([^#]*\)# *\(.*\)/\1\2/p' -e 's/.*[uU]sage: \(.*\)./\1/p' | egrep -i "${1:-.}" | sort 
}
function findd #dir [name] -- find matching directories
{       find . -type d  -name "*$2*"  -not -path "*.git*" | egrep -i "${1:-.}"
}
function finde #env -- find matching environment variables
{       set | egrep '^[0-9_a-zA-Z]+=' | sort -f | egrep -i "${1:-.}"
}
function findf #file [name] -- find matching files
{       find . -type f -name "*$2*" -not -path "*.git*" | egrep -i "${1:-.}"
}
function findh #history -- find matching history commands
{       history | egrep -i "${1:-.}"
}
function findp #process -- find matching processes -W for windows
{       local OPT="ax -F"
        if [[ $IS_WINDOWS ]]; then 
            OPT=-efW 
        elif [[ $IS_MAC ]]; then
            OPT=-A
        fi
        ps $OPT | egrep -i "${1:-.}" | grep -v egrep
}
# Due to xargs_i egrep and pipefail, findt always reports an error
function findt #text [name] -- find file lines that match text [egrep] and name, cut 150
{       find . -type f -name "*$2*" -not -path "*.git*" | tr -d "'" | xargs_i egrep -H -i "${1:-.}" {} | cut -c 1-150
}
function findtt #text [name] -- find files that match text [egrep] and name
{       find . -type f -name "*$2*" -not -path "*.git*" | tr -d "'" | xargs_i egrep -H -i -l "${1:-.}" {}
}
function findx #xfile [name] -- find files matching name that do not match xfile [egrep]
{       find . -type f -name "*$2*" -not -path "*.git*" | tr -d "'" | egrep -i -v "${1:-.}"
}
function findxt #xfile text [name] -- except for xfiles [egrep], find file lines that match text and name, cut 150
{       find . -type f  -name "*$3*" -not -path "*.git*" | tr -d "'" | egrep -i -v "${1:-.}" | xargs_i egrep -H -i "${2:-.}" {} | cut -c 1-150
}
function findxtt #xfile text [name] -- except for xfiles [egrep], find files that match text and name
{       find . -type f  -name "*$3*" -not -path "*.git*"  | tr -d "'" | egrep -i -v "${1:-.}" | xargs_i egrep -H -i -l "${2:-.}" {}
}
alias h='history|tail -20'
alias hh=history
alias l='ls -C -F'
alias ll='ls -lrt'
function newdir #dir -- create a new directory
{       mkdir -p "$1" 
        cd "$1"
}

function autoscp { 
    if [[ $# -ne 3 ]]; then 
        echo 'Usage: autoscp sleep_s "source" dest -- scp on modified ls -l' 
    else 
        local sleep_s=$1 
        local source=$2 
        local dest=$3 
        local stat=always 
        while true; do 
            local newstat=$(ls -l $source | md5sum) 
            if [[ $stat != $newstat ]]; then 
                stat="$newstat" 
                echo "scp -1 $source '$dest'" 
                scp -1 $source "$dest" 
            fi 
            sleep $sleep_s 
        done 
    fi 
}

alias newbashenv="read -p 'Enter to paste new contents for $HOME/.bashenv' && echo 'Paste new contents followed by ^D' &&  cat >$HOME/.bashenv && source $HOME/.bashenv"
alias newsource='source "$HOME/.bashrc"'
function ph #name -- search ~/phone.*
{       cat $HOME/phone.* | egrep -i "$1"
}

##############################
# Set up SSH keychain -- this allows automated access to ssh
#   http://www.gentoo.org/proj/en/keychain
# Notes:
#   Enable this option by creating directories ~/.keychain and ~/.ssh
function setup_keychain # - setup SSH_KEYCHAIN_FILE from ~/.keychain
{
    if [[ -d $HOME/.keychain && -r $HOME/.ssh/id_dsa.pub && $(type -p keychain) ]]; then
        SSH_KEYCHAIN_FILE=$HOME/.keychain/$HOST-sh
        keychain -q id_dsa
        if [[ $? ]]; then
            echo "setup_keychain [etc/road-bashrc.sh]: Could not invoke 'keychain id_dsa'"
            unset SSH_KEYCHAIN_FILE
        elif [[ -r $SSH_KEYCHAIN_FILE ]]; then
            source $SSH_KEYCHAIN_FILE
            export SSH_KEYCHAIN_FILE
        else
            echo "setup_keychain [etc/road-bashrc.sh]: SSH keychain exists, but could not find $SSH_KEYCHAIN_FILE"
            unset SSH_KEYCHAIN_FILE
        fi
    fi
}

if [[ -r $HOME/bash/etc/road-hostrc.sh ]]; then 
    source "$HOME/bash/etc/road-hostrc.sh"
elif [[ -r /etc/road-hostrc.sh ]]; then 
    source /etc/road-hostrc.sh
fi
if [[ -r $HOME/.bash-$HOST ]]; then
    source "$HOME/.bash-$HOST"
else 
    touch "$HOME/.bash-$HOST"
fi

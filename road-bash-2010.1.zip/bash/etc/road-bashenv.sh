#/etc/road-bashenv.sh -- bash environment for scripts and interactive shells
#
# http://www.qhull.org/bash/doc/road-bash.html
# 
# Sourced by ~/.bashrc and /etc/road-bashscript.sh
# When done, it sources /etc/road-hostenv.sh for host-specific settings 
# Then ~/.bashrc sources /etc/road-bashrc.sh and ~/.bashenv
#
#Derived from 
#       matt, jimf, cynthia, and bradb's .cshrc files
#       tcsh docs, example.tcshrc
#       http://road.atg.com/road/software/tcsh.jthml
#       //road.ltsave.com/web/main/software/cshrc.txt
#
# Assumes HOME, PATH, HOST or HOSTNAME, and USER or USERNAME are defined
#
# Exports HOST, USER, TMP, TEMP, EDITOR
#
# Windows portability
#   /a and /b refer to the floppy disks (A: and B:)
#   -d //a/... is slow -- it searches the network drives?
#
# Mac portability
#   sed uses -E instead of -r.  It does not support \L or /i in substitutions.
#   date, ps, and ipconfig have different parameters
#
# $Id: //main/2005/road/road-bash/etc/road-bashenv.sh#21 $
# $DateTime: 2010/01/02 16:25:30 $$Author: bbarber $$Change: 1136 $

# ====== define names =========================

# If directory defined, added to PATH
#ro_bin=//a/logs/home/bbarber/bin

##############################
#  Identify the platform

unset IS_BASH3 IS_CYGWIN IS_MAC IS_MSYS IS_WINDOWS # duplicate in local/bin/ssh
if [[ $WINDIR && -d $WINDIR ]]; then
    IS_WINDOWS=1
    if [[ $OSTYPE == "msys" ]]; then
        IS_MSYS=1
    elif  [[ $OSTYPE == "cygwin" ]]; then
        IS_CYGWIN=1
    fi
else
    if [[ ${OSTYPE//darwin*} == "" ]]; then
        IS_MAC=1
    fi
fi

if [[ ${BASH_VERSINFO[0]} -ge 3 ]]; then
    IS_BASH3=1
fi

ro_version="Road Bash 2009.1"

##############################
#  Check PATH on Windows systems.  Add /usr/util and $ro_bin to path if available
#  Windows and Mac functions

ro_pathinit="${ro_pathinit:-$PATH}"
PATH="$ro_pathinit"

if [[ $IS_WINDOWS ]]; then
    # echo "\$PATH=$PATH"
    ro_find=$(type -p find)
    if [[ ${ro_find/\/bin*} && ${ro_find/\/usr*} ]]; then
        PATH="/usr/local/bin:/bin:$PATH"
        export PATH
    fi
    unset ro_find
fi
if [[ -d /usr/util && ${PATH/*\/usr\/util:*} ]]; then
    PATH="/usr/util:$PATH"
    export PATH
fi

if [[ $ro_bin && ${PATH##*$ro_bin*} ]]; then 
   if [[ ! $IS_WINDOWS || (${ro_bin##/a/*} && ${ro_bin##/b/*}) ]]; then  # skip A: and B:
       if [[ -d $ro_bin ]]; then
           PATH="$ro_bin:$PATH"
           export PATH
       fi
   fi
fi

# Mac OS X does not support -i, nor MSYS -I
if xargs -I {} </dev/null 2>/dev/null; then
    alias xargs_i='xargs -I {}'
else
    alias xargs_i='xargs -i'
fi

# Does not translate /local etc.
function ro_winpath #path -- return Windows format for /d/ and /.  Windows does not accept '\ '
{
    echo $1 | sed -e 's|^/\([a-z]\)/|\1:\\|' -e 's/\\ / /g' -e 's|/|\\|g'
}

function ro_unixpath { #path -- return Unix format for d:, /, and "x x"
    if [[ $IS_MAC ]]; then    # MAC does not lower case with \L
        echo $1 | sed -e 's|^\([a-zA-Z]\):[\\/]|/\1/|' -e 's|\\|/|g' -e 's|/? |\\ |g' 
    else
        echo $1 | sed -e 's|^\([a-zA-Z]\):[\\/]|/\L\1\E/|' -e 's|\\|/|g' -e 's|/? |\\ |g' 
    fi
}

##############################
#  Define HOST, umask, TMP, TEMP
#
umask 002
HOST=${HOST:-$HOSTNAME}
TEMP=/var/tmp
TMP=/var/tmp
USER=${USER:-$USERNAME}

export HOST TEMP TMP USER


##############################
# Time functions
#
function ro_minute # e.g., 15:02, a 24-hour minute
{
    /bin/date +"%H:%M"
}
function ro_now # e.g., 2005-04-21T15:02:10, ISO 8601 datetime for logging 
{
    /bin/date +"%Y-%m-%dT%H:%M:%S"
}
function ro_today # e.g., 2005-04-21, a valid date for wzzip, and Unix
{
    /bin/date +"%Y-%m-%d"
}

function daysago
{
    if [[ ! ($1 == "0" || $1 -gt 0 || $1 -lt 0) ]]; then
        echo 'Usage: daysago n -- return idate for n days ago'
    else
        local now=$(idate)  # Handle platform differences 
        echo $(($now - $1 * 86400)) 
    fi 
}

function idate # [sec] [date-options] -- Convert epoch seconds for logging
{
    local sec=$1
    shift
    if [[ $sec && $IS_MAC ]]; then
        date -u -r $sec
    elif [[ $sec ]]; then
        date -d "1970-01-01 $sec sec UTC" "$@"
    else
        date +"%s"
    fi
}

function idate2
{
    if [[ $# -eq 0 ]]; then
        echo 'Usage: idate2 date [date-options] -- Convert date to epoch seconds'
        return 1
    fi
    local date=$1
    shift
    if [[ $IS_MAC ]]; then
        perl -mTime::Local=timegm -e " 
           @T=split(/[-: T]+/, \"$date\");
           print timegm(@T[5], @T[4], @T[3], @T[2], @T[1]-1, @T[0]-1900), \"\\n\"; 
        " 
    else
      date -d "$date" +"%s" "$@"
    fi
}


##############################
# Define EDITOR and P4EDITOR 
#
if [[ $IS_WINDOWS ]]; then
    if [[ -e /c/bash/util/TextPad/TextPad.exe ]]; then
        EDITOR=/c/bash/util/TextPad/TextPad.exe
        P4EDITOR="${P4EDITOR:-C:\\bash\\util\\TextPad\\TextPad.exe}"
    else
        EDITOR=Notepad
        P4EDITOR="${P4EDITOR:-Notepad}"
    fi
else
    if [[ $(type -p emacs) ]]; then
        EDITOR=emacs
        P4EDITOR="${P4EDITOR:-emacs}"
    elif [[ $(type -p vim) ]]; then
        EDITOR=vim
        P4EDITOR="${P4EDITOR:-vim}"
    else 
        EDITOR=vi
        P4EDITOR="${P4EDITOR:-vi}"
    fi
fi
export EDITOR

##############################
# Set up Perforce
#

if [[ $(type -p p4) ]]; then
    if [[ -r $HOME/.p4config ]]; then
        chmod 600 $HOME/.p4config
        source $HOME/.p4config
        if [[ $P4PASSWD ]]; then
            export P4PASSWD
        fi
    fi
    P4PORT=${P4PORT:-1666}
    P4CONFIG=${P4CONFIG:-p4config.txt}
    P4USER=${P4USER:-$USER}
    export P4CONFIG P4EDITOR P4PORT P4USER
    if [[ $IS_WINDOWS && ! $IS_MSYS ]]; then
        alias p4="unset PWD && p4"
    fi

else
    unset P4EDITOR
fi


################################### 
# Useful functions
#
function cdw #path -- cd to path in Windows or Unix speak
{
    cd $(ro_unixpath "$1")
}

function file_swap #file1 file2 -- swap file1 with file2 (e.g., for testing)
{
        mv "$1" "$1.temp.$$"
        mv "$2" "$1"
        sleep 1 # Otherwise, may report an error: No such file or directory
        mv "$1.temp.$$" "$2"
}

function ro_hostip # -- Return IP address of host
{
    if [[ $IS_WINDOWS ]]; then
        ipconfig | sed -n 's/.*IP Address.*: //p'
    elif [[ $IS_MAC ]]; then
        ipconfig getifaddr en0
    else
        hostname -i | sed 's/ //g'
    fi
}




if [[ -r $HOME/bash/etc/road-hostenv.sh ]]; then 
    source "$HOME/bash/etc/road-hostenv.sh"
elif [[ -r /etc/road-hostenv.sh ]]; then
    source /etc/road-hostenv.sh
fi

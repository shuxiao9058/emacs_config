
Contents of /local/bin            http://www.qhull.org/bash/doc/road-bash.html

    Unix-like programs that are short, useful, and freely redistributed
    Documentation and copyright notices are in /doc/local-bin
    Invoke with --help for usage notes
    Copyrights are GPL or open source.

Links to /local programs
    Packages go into /local/name or /util/name with a link in /local/bin
    ssh, scp, sftp -- install /util/putty for secure shell, copy, and FTP

Road scripts
    p4edit -- open modified files for edit in Perforce
    p4update -- open, add, or delete files in a directory for Perforce
    road-make.sh -- Create the bash and road distributions
    road-test.sh -- Test the bash installation

=== Windows distribution (zip) ===

From UnxUtils/update (http://unxutils.sourceforge.net/)
    sed -- GNU 4.02

From Outwit (http://www.dmst.aueb.gr/dds/sw/outwit/outwit-bin-1.26.zip)
    docprop -- Properties of OLE docs (e.g., Word)
    odbc -- Read access to ODBC resources
    readlog -- Read Windows event logs
    winclip -- Read and write Windows clipboard
    winreg -- Read Windows registry

From GnuWin32 -- (http://sourceforge.net/projects/gnuwin32/)
  Packages & contents -- http://gnuwin32.sourceforge.net/packages.html

  coreutils-5.3.0 (http://www.gnu.org/software/coreutils)
    libiconv2.dll -- convert between character encodings, required by du.exe
    libintl3.dll -- library for native language support, required by du.exe
    popt1.dll -- parse command line options, required by cygutils
    csplit -- Split file into sections    
    du -- Disk usage
    df -- Disk mounts
    expand -- Convert tabs to spaces
    fmt -- Format paragraphs
    hostid -- Identifier for host in hex
    hostname -- Name of host
    kill -- Kill process and send signals
    od -- Binary dump of a file
    stat -- File status
    tsort -- Topological sort
    unexpand -- Convert spaces to tabs
    whoami -- return current user
    yes -- return 'yes', e.g., for answering prompts

  cygutils-1.2.9 (http://cygutils.fruitbat.org/cygutils-package)
    colrm -- Remove one or more columns from a file
    column -- Format output into columns
    d2u -- Convert text files from CRLF to LF line ending (aka conv)
    u2d -- Convert text files from LF to CRLF line ending (aka conv)
    readshortcut -- Read windows shortcut
    mkshortcut -- Create windows shortcut

Considered but not included
    crontab (GNU's mcron package.  Is it available for Windows?)
    cygstart (cygutils) -- Start window programs, duplicates 'start', includes actions
    lpr (cygutils) -- streaming to windows printers
    redir (mingw-utils) -- Redirect I/O from DJGPP
    script (http://freshmeat.net/projects/util-linux/) -- needs porting.  Featured in Linux Cookbook
               http://www.dsl.org/cookbook/cookbook_5.html#SEC68
    sed 4.2.1 (msys sed and gnuwin32) -- msys sed is 100x larger than unxutils
    msys cygutils 1.3.4 does not include d2u, u2d, column, or colrm
    msys coreutils 5.97 is 1Mbyte per util
    
